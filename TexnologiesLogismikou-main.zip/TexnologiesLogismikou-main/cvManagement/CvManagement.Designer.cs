﻿
namespace cvManagement
{
    partial class CvManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.add = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.editButton = new System.Windows.Forms.Button();
            this.addBiographyData = new System.Windows.Forms.Button();
            this.interestBox = new System.Windows.Forms.ComboBox();
            this.skillBox = new System.Windows.Forms.ComboBox();
            this.experienceBox = new System.Windows.Forms.ComboBox();
            this.languageBox = new System.Windows.Forms.ComboBox();
            this.diplomaBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.mixedButton = new System.Windows.Forms.RadioButton();
            this.femaleButton = new System.Windows.Forms.RadioButton();
            this.maleButton = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.helloLabel = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1394, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI Historic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(189, -3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(360, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Curriculum Vitae List";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Location = new System.Drawing.Point(0, 598);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1394, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // add
            // 
            this.add.BackColor = System.Drawing.SystemColors.ControlDark;
            this.add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add.Location = new System.Drawing.Point(1249, 406);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(99, 44);
            this.add.TabIndex = 21;
            this.add.Text = "Add";
            this.add.UseVisualStyleBackColor = false;
            this.add.Click += new System.EventHandler(this.add_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(54, 56);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(997, 466);
            this.dataGridView1.TabIndex = 23;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // editButton
            // 
            this.editButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.editButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.editButton.Location = new System.Drawing.Point(1073, 406);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(99, 44);
            this.editButton.TabIndex = 24;
            this.editButton.Text = "Edit";
            this.editButton.UseVisualStyleBackColor = false;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // addBiographyData
            // 
            this.addBiographyData.BackColor = System.Drawing.Color.Transparent;
            this.addBiographyData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addBiographyData.Location = new System.Drawing.Point(114, 329);
            this.addBiographyData.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addBiographyData.Name = "addBiographyData";
            this.addBiographyData.Size = new System.Drawing.Size(136, 29);
            this.addBiographyData.TabIndex = 35;
            this.addBiographyData.Text = "Serach";
            this.addBiographyData.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.addBiographyData.UseVisualStyleBackColor = false;
            this.addBiographyData.Click += new System.EventHandler(this.addBiographyData_Click);
            // 
            // interestBox
            // 
            this.interestBox.FormattingEnabled = true;
            this.interestBox.Items.AddRange(new object[] {
            "Volunteering and community involvement",
            "Writing",
            "Blogging",
            "Podcasting",
            "Marketing",
            "Learning languages",
            "Photography",
            "Travel",
            "Sports",
            "Art",
            "Making-Listening to music"});
            this.interestBox.Location = new System.Drawing.Point(126, 256);
            this.interestBox.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.interestBox.Name = "interestBox";
            this.interestBox.Size = new System.Drawing.Size(124, 23);
            this.interestBox.TabIndex = 34;
            this.interestBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // skillBox
            // 
            this.skillBox.FormattingEnabled = true;
            this.skillBox.Items.AddRange(new object[] {
            "Creativity",
            "Interpersonal Skills",
            "Critical Thinking",
            "Problem Solving",
            "Public Speaking",
            "Customer Service Skills",
            "Teamwork Skills",
            "Communication",
            "Collaboration",
            "Accounting",
            "Active Listening",
            "Adaptability",
            "Negotiation",
            "Conflict Resolution",
            "Empathy",
            "Customer Service",
            "Decision Making",
            "Management",
            "Leadership skills",
            "Organization",
            "Language skills",
            "Administrative skills"});
            this.skillBox.Location = new System.Drawing.Point(129, 213);
            this.skillBox.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.skillBox.Name = "skillBox";
            this.skillBox.Size = new System.Drawing.Size(124, 23);
            this.skillBox.TabIndex = 33;
            this.skillBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // experienceBox
            // 
            this.experienceBox.FormattingEnabled = true;
            this.experienceBox.Items.AddRange(new object[] {
            "Mechanical Engineer",
            "Web Developer",
            "Java Developer",
            "Electrical Engineer",
            "Electronic Engineer",
            "Chemical Engineer",
            "Statistician",
            "Data Analyst",
            "Ecologist",
            "Programmer"});
            this.experienceBox.Location = new System.Drawing.Point(139, 168);
            this.experienceBox.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.experienceBox.Name = "experienceBox";
            this.experienceBox.Size = new System.Drawing.Size(124, 23);
            this.experienceBox.TabIndex = 32;
            this.experienceBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // languageBox
            // 
            this.languageBox.FormattingEnabled = true;
            this.languageBox.Items.AddRange(new object[] {
            "English",
            "Greek",
            "French",
            "Italian",
            "Spanish",
            "Chinese",
            "Russian ",
            "German"});
            this.languageBox.Location = new System.Drawing.Point(192, 126);
            this.languageBox.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.languageBox.Name = "languageBox";
            this.languageBox.Size = new System.Drawing.Size(124, 23);
            this.languageBox.TabIndex = 31;
            this.languageBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // diplomaBox
            // 
            this.diplomaBox.FormattingEnabled = true;
            this.diplomaBox.Items.AddRange(new object[] {
            "Computer Science",
            "Economics",
            "Mathematics",
            "History",
            "Sound and visual arts",
            "Statistics",
            "Biology",
            "Physics",
            "Digital Systems"});
            this.diplomaBox.Location = new System.Drawing.Point(114, 70);
            this.diplomaBox.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.diplomaBox.Name = "diplomaBox";
            this.diplomaBox.Size = new System.Drawing.Size(124, 23);
            this.diplomaBox.TabIndex = 30;
            this.diplomaBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(22, 256);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 18);
            this.label5.TabIndex = 29;
            this.label5.Text = "Interests:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(22, 212);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 28;
            this.label4.Text = "Skills:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(17, 124);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 18);
            this.label2.TabIndex = 26;
            this.label2.Text = "Foreign languages:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(17, 73);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 18);
            this.label6.TabIndex = 25;
            this.label6.Text = "Diploma:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(17, 166);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 18);
            this.label3.TabIndex = 27;
            this.label3.Text = "Experience:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mixedButton);
            this.groupBox1.Controls.Add(this.femaleButton);
            this.groupBox1.Controls.Add(this.maleButton);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.diplomaBox);
            this.groupBox1.Controls.Add(this.addBiographyData);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.interestBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.skillBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.experienceBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.languageBox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(1056, 16);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(325, 384);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Information";
            this.groupBox1.Visible = false;
            // 
            // mixedButton
            // 
            this.mixedButton.AutoSize = true;
            this.mixedButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mixedButton.Location = new System.Drawing.Point(255, 296);
            this.mixedButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mixedButton.Name = "mixedButton";
            this.mixedButton.Size = new System.Drawing.Size(58, 19);
            this.mixedButton.TabIndex = 39;
            this.mixedButton.TabStop = true;
            this.mixedButton.Text = "mixed";
            this.mixedButton.UseVisualStyleBackColor = true;
            // 
            // femaleButton
            // 
            this.femaleButton.AutoSize = true;
            this.femaleButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.femaleButton.Location = new System.Drawing.Point(183, 296);
            this.femaleButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.femaleButton.Name = "femaleButton";
            this.femaleButton.Size = new System.Drawing.Size(61, 19);
            this.femaleButton.TabIndex = 38;
            this.femaleButton.TabStop = true;
            this.femaleButton.Text = "female";
            this.femaleButton.UseVisualStyleBackColor = true;
            // 
            // maleButton
            // 
            this.maleButton.AutoSize = true;
            this.maleButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.maleButton.Location = new System.Drawing.Point(125, 296);
            this.maleButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maleButton.Name = "maleButton";
            this.maleButton.Size = new System.Drawing.Size(51, 19);
            this.maleButton.TabIndex = 37;
            this.maleButton.TabStop = true;
            this.maleButton.Text = "male";
            this.maleButton.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(36, 293);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 18);
            this.label9.TabIndex = 36;
            this.label9.Text = "Gender:";
            // 
            // helloLabel
            // 
            this.helloLabel.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.helloLabel.Location = new System.Drawing.Point(786, 22);
            this.helloLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.helloLabel.Name = "helloLabel";
            this.helloLabel.Size = new System.Drawing.Size(238, 19);
            this.helloLabel.TabIndex = 40;
            // 
            // CvManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1394, 620);
            this.Controls.Add(this.helloLabel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.add);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "CvManagement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CV List";
            this.Load += new System.EventHandler(this.CvManagement_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button editButton;
        private System.Windows.Forms.Button addBiographyData;
        private System.Windows.Forms.ComboBox interestBox;
        private System.Windows.Forms.ComboBox skillBox;
        private System.Windows.Forms.ComboBox experienceBox;
        private System.Windows.Forms.ComboBox languageBox;
        private System.Windows.Forms.ComboBox diplomaBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton femaleButton;
        private System.Windows.Forms.RadioButton maleButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton mixedButton;
        private System.Windows.Forms.Label helloLabel;
    }
}