﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cvManagement
{
    //Implements ISpeak interface
    public class Admin :Human, ISpeak
    {
        string username = "admin";
        string password = "admin";

        //constructor for admin human
        public Admin()
            :base("admin", "admin")
        { }

        public string WhoAmI()
        {
            return "Hi Admin!!";
        }
    }
}
