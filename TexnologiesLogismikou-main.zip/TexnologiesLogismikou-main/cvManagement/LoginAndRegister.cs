﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;

namespace cvManagement
{
    public partial class LoginAndRegister : Form
    {

        string connectionString;

        public LoginAndRegister()
        {
            InitializeComponent();

            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);

            connectionString = @"Data Source=C:\Users\strat\Desktop\TexnologiesLogismikou-main\cvManagement\bin\Debug\students.db; Version = 3";
        }

        private void button_GoToLogin_Click(object sender, EventArgs e)
        {
            panel_login.BringToFront();
            panel_login_bar.BackColor = Color.Yellow;
            panel_register_bar.BackColor = select_color;
            button_GoToLogin.BackColor = select_color;
            button_GoToRegister.BackColor = Color.Black;
        }

        private void button_GoToRegister_Click(object sender, EventArgs e)
        {
            panel_register.BringToFront();
            panel_register_bar.BackColor = Color.Yellow;
            panel_login_bar.BackColor = select_color;
            button_GoToRegister.BackColor = select_color;
            button_GoToLogin.BackColor = Color.Black;

            adminInfo.Visible = false;
        }
        Color select_color = Color.FromArgb(49, 46, 46);

        private void LoginAndRegister_Load(object sender, EventArgs e)
        {
            button_GoToLogin.PerformClick();
        }

        //We check who is using the app, Student, Admin or Unipi
        private void login_Click(object sender, EventArgs e)
        {
            //for admin
            if (username.Text == "admin" && password.Text == "admin")
            {
                Admin admin = new Admin();
                CvManagement cvmanagement = new CvManagement(admin);
                cvmanagement.Show();
                Hide();

            }
            else if (username.Text == "unipi" && password.Text == "unipi")
            {
                Unipi unipi = new Unipi();
                CvManagement cvmanagement = new CvManagement(unipi);
                cvmanagement.Show();
                Hide();
            }
            else
            {
                //log in validation from the data base
                using (SQLiteConnection con = new SQLiteConnection(connectionString))
                {
                    try
                    {
                        SQLiteCommand cmd = new SQLiteCommand();
                        cmd.CommandText = "SELECT * FROM students_reg where USERNAME = '" + username.Text + "' AND PASSWORD = '" + password.Text + "'";
                        cmd.Connection = con;

                        con.Open();
                        SQLiteDataAdapter da = new SQLiteDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        int i = cmd.ExecuteNonQuery();
                        con.Close();
                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show("You are logged in!");
                            //Here we load the student object from the databaase
                            Student student = con.Query<Student>("select FIRST_NAME, LAST_NAME, USERNAME, PASSWORD from students_reg where USERNAME = '" + username.Text + "'").SingleOrDefault();
                            CvManagement cv = new CvManagement(student);
                            this.Hide();
                            cv.Show();
                        }
                        else
                        {
                            MessageBox.Show("Maybe you typed something wrong! Try again.");
                        }

                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }

        }




        //Register Button
        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(firstName.Text))
            {
                errorProviderFirstName.SetError(firstName, "First name should not be left blank!");
            }
            else
            {
                errorProviderFirstName.SetError(firstName, "");
            }

            if (string.IsNullOrWhiteSpace(lastName.Text))
            {
                errorProvider1.SetError(lastName, "Last name should not be left blank!");
            }
            else
            {
                errorProvider1.SetError(lastName, "");
            }


            if (string.IsNullOrWhiteSpace(user.Text))
            {
                errorProvider2.SetError(lastName, "Username should not be left blank!");
            }
            else
            {
                errorProvider1.SetError(lastName, "");
            }

            if (pass.Text != confirmPass.Text)
            {
                MessageBox.Show("passwords dont match");
            }

            if (agreeWithTerms.Checked == false)
            {
                MessageBox.Show("you need to agree with terms to continue with registration");
            }

            if (agreeWithTerms.Checked == true)
            {
                Student student = new Student(firstName.Text, lastName.Text, user.Text, pass.Text);
                using (SQLiteConnection con = new SQLiteConnection(connectionString))
                {
                    try
                    {
                        //instertion of new register
                        SQLiteCommand cmd = new SQLiteCommand();
                        cmd.CommandText = "insert into students_reg (FIRST_NAME,LAST_NAME,USERNAME,PASSWORD)values('" + student.First_name + "', '" + student.Last_name + "', '" + student.Usename + "', '" + student.Password + "')";
                        cmd.Connection = con;

                        con.Open();

                        int i = cmd.ExecuteNonQuery();

                        //grab last inster ID
                        cmd.CommandText = "select last_insert_rowid()";

                        // The row ID is a 64-bit value - cast the Command result to an Int64.
                        //
                        Int64 LastRowID64 = (Int64)cmd.ExecuteScalar();

                        // Then grab the bottom 32-bits as the unique ID of the row.
                        //
                        int LastRowID = (int)LastRowID64;


                        //intialization in students_info
                        cmd.CommandText = "insert into students_info (Id,  Gender,  Diploma, Language, Experience, Skill, Interest)values('" + LastRowID + "' ,'" + student.Gender + "', '" + student.Diploma + "', '" + student.Language + "', '" + student.Experience + "', '" + student.Skill + "', '" + student.Interest + "')";
                        cmd.Connection = con;


                        i = cmd.ExecuteNonQuery();
                        con.Close();

                        string username = user.Text;

                        con.Open();
                        CvManagement cv = new CvManagement(student);
                        this.Hide();
                        cv.Show();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void confirmPass_TextChanged(object sender, EventArgs e)
        {
            if (!pass.Text.Equals(String.Empty) && pass.Text.Equals(confirmPass.Text))
                button1.Enabled = true;
            else
                button1.Enabled = false;
        }

        private void lastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsPunctuation(e.KeyChar) ||
                        Char.IsSeparator(e.KeyChar) ||
                        Char.IsSymbol(e.KeyChar);
        }

        private void termsAndServicesLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("•You must be a senior or graduate student to use this application." + "\n" + "•You agree to share your cv and every information required in this app." + "\n" + "•You must respect the privacy of each user of the app.");
        }

    }
}
