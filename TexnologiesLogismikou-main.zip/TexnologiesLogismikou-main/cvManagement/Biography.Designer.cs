﻿
namespace cvManagement
{
    partial class Biography
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Biography));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.diplomaBox = new System.Windows.Forms.ComboBox();
            this.languageBox = new System.Windows.Forms.ComboBox();
            this.experienceBox = new System.Windows.Forms.ComboBox();
            this.skillBox = new System.Windows.Forms.ComboBox();
            this.interestBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.addBiographyData = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.phoneBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.maleButton = new System.Windows.Forms.RadioButton();
            this.femaleButton = new System.Windows.Forms.RadioButton();
            this.BackPictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.BackPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(803, 325);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Diploma:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(803, 377);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Foreign languages:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(803, 431);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Experience:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(803, 487);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Skills:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(803, 546);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Interests:";
            // 
            // diplomaBox
            // 
            this.diplomaBox.FormattingEnabled = true;
            this.diplomaBox.Items.AddRange(new object[] {
            "Computer Science",
            "Economics",
            "Mathematics",
            "History",
            "Sound and visual arts",
            "Statistics",
            "Biology",
            "Physics",
            "Digital Systems"});
            this.diplomaBox.Location = new System.Drawing.Point(1013, 325);
            this.diplomaBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.diplomaBox.Name = "diplomaBox";
            this.diplomaBox.Size = new System.Drawing.Size(171, 33);
            this.diplomaBox.TabIndex = 5;
            this.diplomaBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // languageBox
            // 
            this.languageBox.FormattingEnabled = true;
            this.languageBox.Items.AddRange(new object[] {
            "English",
            "Greek",
            "French",
            "Italian",
            "Spanish",
            "Chinese",
            "Russian ",
            "German"});
            this.languageBox.Location = new System.Drawing.Point(1013, 377);
            this.languageBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.languageBox.Name = "languageBox";
            this.languageBox.Size = new System.Drawing.Size(171, 33);
            this.languageBox.TabIndex = 6;
            this.languageBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // experienceBox
            // 
            this.experienceBox.FormattingEnabled = true;
            this.experienceBox.Items.AddRange(new object[] {
            "Mechanical Engineer",
            "Web Developer",
            "Java Developer",
            "Electrical Engineer",
            "Electronic Engineer",
            "Chemical Engineer",
            "Statistician",
            "Data Analyst",
            "Ecologist",
            "Programmer"});
            this.experienceBox.Location = new System.Drawing.Point(1013, 431);
            this.experienceBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.experienceBox.Name = "experienceBox";
            this.experienceBox.Size = new System.Drawing.Size(171, 33);
            this.experienceBox.TabIndex = 7;
            this.experienceBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // skillBox
            // 
            this.skillBox.FormattingEnabled = true;
            this.skillBox.Items.AddRange(new object[] {
            "Creativity",
            "Interpersonal Skills",
            "Critical Thinking",
            "Problem Solving",
            "Public Speaking",
            "Customer Service Skills",
            "Teamwork Skills",
            "Communication",
            "Collaboration",
            "Accounting",
            "Active Listening",
            "Adaptability",
            "Negotiation",
            "Conflict Resolution",
            "Empathy",
            "Customer Service",
            "Decision Making",
            "Management",
            "Leadership skills",
            "Organization",
            "Language skills",
            "Administrative skills"});
            this.skillBox.Location = new System.Drawing.Point(1013, 487);
            this.skillBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.skillBox.Name = "skillBox";
            this.skillBox.Size = new System.Drawing.Size(171, 33);
            this.skillBox.TabIndex = 8;
            this.skillBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // interestBox
            // 
            this.interestBox.FormattingEnabled = true;
            this.interestBox.Items.AddRange(new object[] {
            "Volunteering and community involvement",
            "Writing",
            "Blogging",
            "Podcasting",
            "Marketing",
            "Learning languages",
            "Photography",
            "Travel",
            "Sports",
            "Art",
            "Making-Listening to music"});
            this.interestBox.Location = new System.Drawing.Point(1013, 546);
            this.interestBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.interestBox.Name = "interestBox";
            this.interestBox.Size = new System.Drawing.Size(171, 33);
            this.interestBox.TabIndex = 9;
            this.interestBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(857, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(314, 41);
            this.label6.TabIndex = 10;
            this.label6.Text = "Biography Data";
            // 
            // addBiographyData
            // 
            this.addBiographyData.BackColor = System.Drawing.Color.Transparent;
            this.addBiographyData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addBiographyData.Location = new System.Drawing.Point(900, 624);
            this.addBiographyData.Name = "addBiographyData";
            this.addBiographyData.Size = new System.Drawing.Size(174, 67);
            this.addBiographyData.TabIndex = 11;
            this.addBiographyData.Text = "Add Your Biography Data";
            this.addBiographyData.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.addBiographyData.UseVisualStyleBackColor = false;
            this.addBiographyData.Click += new System.EventHandler(this.addBiographyData_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(487, 377);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 25);
            this.label7.TabIndex = 12;
            this.label7.Text = "Phone number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(497, 297);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 25);
            this.label8.TabIndex = 13;
            this.label8.Text = "Email:";
            // 
            // emailBox
            // 
            this.emailBox.Location = new System.Drawing.Point(662, 297);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(125, 32);
            this.emailBox.TabIndex = 14;
            // 
            // phoneBox
            // 
            this.phoneBox.Location = new System.Drawing.Point(662, 378);
            this.phoneBox.MaxLength = 10;
            this.phoneBox.Name = "phoneBox";
            this.phoneBox.Size = new System.Drawing.Size(125, 32);
            this.phoneBox.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(487, 474);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 25);
            this.label9.TabIndex = 16;
            this.label9.Text = "Gender:";
            // 
            // maleButton
            // 
            this.maleButton.AutoSize = true;
            this.maleButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.maleButton.Location = new System.Drawing.Point(577, 472);
            this.maleButton.Name = "maleButton";
            this.maleButton.Size = new System.Drawing.Size(82, 29);
            this.maleButton.TabIndex = 17;
            this.maleButton.TabStop = true;
            this.maleButton.Text = "male";
            this.maleButton.UseVisualStyleBackColor = true;
            // 
            // femaleButton
            // 
            this.femaleButton.AutoSize = true;
            this.femaleButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.femaleButton.Location = new System.Drawing.Point(665, 474);
            this.femaleButton.Name = "femaleButton";
            this.femaleButton.Size = new System.Drawing.Size(101, 29);
            this.femaleButton.TabIndex = 18;
            this.femaleButton.TabStop = true;
            this.femaleButton.Text = "female";
            this.femaleButton.UseVisualStyleBackColor = true;
            // 
            // BackPictureBox1
            // 
            this.BackPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("BackPictureBox1.Image")));
            this.BackPictureBox1.Location = new System.Drawing.Point(1368, 38);
            this.BackPictureBox1.Name = "BackPictureBox1";
            this.BackPictureBox1.Size = new System.Drawing.Size(121, 93);
            this.BackPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BackPictureBox1.TabIndex = 19;
            this.BackPictureBox1.TabStop = false;
            this.BackPictureBox1.Click += new System.EventHandler(this.BackPictureBox1_Click);
            // 
            // Biography
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1635, 886);
            this.Controls.Add(this.BackPictureBox1);
            this.Controls.Add(this.femaleButton);
            this.Controls.Add(this.maleButton);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.phoneBox);
            this.Controls.Add(this.emailBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.addBiographyData);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.interestBox);
            this.Controls.Add(this.skillBox);
            this.Controls.Add(this.experienceBox);
            this.Controls.Add(this.languageBox);
            this.Controls.Add(this.diplomaBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Biography";
            this.Text = "Biography status";
            this.Load += new System.EventHandler(this.Biography_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.diplomaBox_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.BackPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox diplomaBox;
        private System.Windows.Forms.ComboBox languageBox;
        private System.Windows.Forms.ComboBox experienceBox;
        private System.Windows.Forms.ComboBox skillBox;
        private System.Windows.Forms.ComboBox interestBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button addBiographyData;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.TextBox phoneBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton maleButton;
        private System.Windows.Forms.RadioButton femaleButton;
        private System.Windows.Forms.PictureBox BackPictureBox1;
    }
}