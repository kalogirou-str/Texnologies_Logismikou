﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cvManagement
{
    public partial class CvManagement : Form
    {
        string connectionString;
        int Id;
        Admin admin;
        Student student;
        Unipi unipi;

        //in order to not creating 3 simillar methods for student, unipi and admin
        //we use the Ispeak interface
        public CvManagement(ISpeak obj)
        {
            InitializeComponent();
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);
            

            //different buttons based on the user
            string type = obj.GetType().ToString();
            if (type.Equals("cvManagement.Student") == true)
            {
                this.student = (Student)obj;
                add.Visible = false;

                helloLabel.Text = student.WhoAmI();
                
            }
            else if (type.Equals("cvManagement.Admin") == true)
            {
                this.admin = (Admin)obj;
                helloLabel.Text = admin.WhoAmI();
            }
            else if (type.Equals("cvManagement.Unipi") == true)
            {
                this.unipi = (Unipi)obj;
                groupBox1.Visible = true;
                add.Visible = false;
                editButton.Visible = false;
                mixedButton.Checked = true;

                helloLabel.Text = unipi.WhoAmI();
            }
            connectionString = @"Data Source=C:\Users\strat\Desktop\TexnologiesLogismikou-main\cvManagement\bin\Debug\students.db; Version = 3";
            LoadData();
        }

        //Σύνδεση project με sqlite
        private SQLiteConnection sql_con;
        private SQLiteCommand sql_cmd;
        private SQLiteDataAdapter DB;
        private DataSet DS = new DataSet();
        private DataTable DT = new DataTable();

        private void SetConnection()
        {
            sql_con = new SQLiteConnection(connectionString);
        }

        private void ExecuteQuery(string txtQuery)
        {
            SetConnection();
            sql_con.Open();
            sql_cmd = sql_con.CreateCommand();
            sql_cmd.CommandText = txtQuery;
            sql_cmd.ExecuteNonQuery();
            sql_con.Close();
        }

        private void LoadData()
        {
            SetConnection();
            sql_con.Open();
            sql_cmd = sql_con.CreateCommand();
            string CommandText;
            //for student
            if (student != null)
            {
                add.Visible = false;//student can't add new student
                CommandText = "SELECT USERNAME, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest  FROM students_reg NATURAL JOIN students_info where USERNAME='" + student.Usename + "' ORDER by ID";
            }
            //for admin
            else
            {
                CommandText = "SELECT ID, USERNAME, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest FROM students_reg NATURAL JOIN students_info ORDER by ID";
            }

            DB = new SQLiteDataAdapter(CommandText, sql_con);
            DS.Reset();
            DB.Fill(DS);
            DT = DS.Tables[0];
            dataGridView1.DataSource = DT;
            sql_con.Close();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginAndRegister loginAndRegister = new LoginAndRegister();
            loginAndRegister.Show();
            this.Hide();
        }
        
        private void editButton_Click(object sender, EventArgs e)
        {
            if(student == null)
            {
                Biography biography = new Biography(Id, admin);
                biography.Show();
            }
            else
            {
                Biography biography = new Biography(student);
                biography.Show();
            }
            this.Close();
        }

        //Taking the ID of a record
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                Id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
        }

        //For searching
        private void addBiographyData_Click(object sender, EventArgs e)
        {
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                con.Open();
                try
                {
                    string CommandText = "select ID, USERNAME, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest from students_info NATURAL JOIN students_reg";
                    string CommandTextCopie = CommandText;



                    if (diplomaBox.Text != "")
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        CommandText += " Diploma='" + diplomaBox.Text + "'";
                    }
                    if (languageBox.Text != "")
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        CommandText += " Language='" + languageBox.Text + "'";
                    }
                    if (experienceBox.Text != "")
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        CommandText += " Experience='" + experienceBox.Text + "'";
                    }
                    if (skillBox.Text != "")
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        CommandText += " Skill='" + skillBox.Text + "'";
                    }
                    if (interestBox.Text != "")
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        CommandText += " Interest='" + interestBox.Text + "'";
                    }

                    if (mixedButton.Checked == false)
                    {
                        if (CommandTextCopie == CommandText)
                        {
                            CommandText += " where";
                        }
                        else
                        {
                            CommandText += " and";
                        }
                        if (maleButton.Checked == true)
                        {
                            CommandText += " Gender='male'";
                        }
                        else if (femaleButton.Checked == true)
                        {
                            CommandText += " Gender='female'";
                        }
                    }


                    DB = new SQLiteDataAdapter(CommandText, sql_con);
                    DS.Reset();
                    DB.Fill(DS);
                    DT = DS.Tables[0];
                    dataGridView1.DataSource = DT;
                    sql_con.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            UserAddAdmin userAddAdmin = new UserAddAdmin(admin);
            userAddAdmin.Show();
            this.Close();
        }
        private void CvManagement_Load(object sender, EventArgs e)
        {
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);
        }
    }
}

