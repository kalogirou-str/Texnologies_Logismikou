﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cvManagement
{
    public class Unipi : Human, ISpeak
    {
        string username = "unipi";
        string password = "unipi";

        //constructor for unipi human
        public Unipi()
            : base("unipi", "unipi")
        { }

        public string WhoAmI()
        {
            return "Hi Unipi!!";
        }
    }
}
