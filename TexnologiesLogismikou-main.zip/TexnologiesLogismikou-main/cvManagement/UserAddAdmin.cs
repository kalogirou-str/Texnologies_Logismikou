﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cvManagement
{
    public partial class UserAddAdmin : Form
    {

        string connectionString = @"Data Source= C:\Users\strat\Desktop\TexnologiesLogismikou-main\cvManagement\bin\Debug\students.db; Version = 3";
        Admin admin;

        public UserAddAdmin(Admin admin)
        {
            InitializeComponent();

            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);

            this.admin = admin;
        }

        static Regex validate_emailaddress = email_validation();

        private static Regex email_validation()
        {
            string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

            return new Regex(pattern, RegexOptions.IgnoreCase);
        }

        private void add_Click(object sender, EventArgs e)
        {
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                con.Open();
                try
                {
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.CommandText = "insert into students_reg (FIRST_NAME,LAST_NAME,USERNAME,PASSWORD)values('" + firstName.Text + "', '" + lastName.Text + "', '" + user.Text + "', '" + pass.Text + "')";
                    cmd.Connection = con;
                    int i = cmd.ExecuteNonQuery();

                    cmd = con.CreateCommand();
                    cmd.CommandText = "SELECT ID FROM students_reg WHERE USERNAME='" + user.Text + "'";  //set the passed query
                    int id = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.CommandText = "insert into students_info (Id, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest)values('" + id + "' ,'" + emailBox.Text + "', '" + maleButton.Text + "', '" + phoneBox.Text + "', '" + diplomaBox.Text + "', '" + languageBox.Text + "', '" + experienceBox.Text + "', '" + skillBox.Text + "', '" + interestBox.Text + "')";
                    i = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                    CvManagement cv = new CvManagement(admin);
                    cv.Show();
                    this.Hide();

                }
            }
        }

        private void UserAddAdmin_Load(object sender, EventArgs e)
        {
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);
        }

        private void firstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void diplomaBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (emailBox.Text.Length == 0 || phoneBox.Text.Length == 0 || (maleButton.Checked == false && femaleButton.Checked == false) || firstName.Text.Length == 0 || lastName.Text.Length == 0 || user.Text.Length == 0 || pass.Text.Length == 0 || confirmPass.Text.Length == 0)
            {
                blankTextbox.Visible = true;
                add.Enabled = false;
                checkBox1.Checked = false;
            }
            else
            {
                blankTextbox.Visible = false;
                if (checkBox1.Checked == true)
                {

                    if (validate_emailaddress.IsMatch(emailBox.Text) != true)
                    {
                        MessageBox.Show("Invalid Email Address!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        checkBox1.Checked = false;
                        emailBox.Focus();
                        add.Enabled = false;
                    }

                    else if (checkBox1.Checked == false)
                    {
                        add.Enabled = false;
                    }
                    else if (phoneBox.Text.Trim().Length != 10)
                    {
                        MessageBox.Show("Invalid Phone Number!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        checkBox1.Checked = false;

                        phoneBox.Focus();
                    }
                    else if (pass.Text != confirmPass.Text)
                    {
                        MessageBox.Show("Passwords dont match");
                        checkBox1.Checked = false;
                        add.Enabled = false;
                    }
                    else if (validate_emailaddress.IsMatch(emailBox.Text) == true && phoneBox.Text.Trim().Length == 10 && checkBox1.Checked == true && pass.Text == confirmPass.Text)
                    {
                        add.Enabled = true;
                    }
                   
                }
            }
        }

        private void user_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsLetterOrDigit(e.KeyChar)     // Allowing only any letter OR Digit

            || e.KeyChar == '\b')                 // Allowing BackSpace character
            {
                e.Handled = false;
            }
            else 
            {
                e.Handled = true;
            }
        }

        private void phoneBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

        }

        private void phoneBox_TextChanged(object sender, EventArgs e)
        {
            if (emailBox.Text.Length == 0 || phoneBox.Text.Length == 0 || (maleButton.Checked == false && femaleButton.Checked == false) || firstName.Text.Length == 0 || lastName.Text.Length == 0 || user.Text.Length == 0 || pass.Text.Length == 0 || confirmPass.Text.Length == 0)
            {
                blankTextbox.Visible = true;
                add.Enabled = false;
                checkBox1.Checked = false;
            }
            else
            {
                blankTextbox.Visible = false;
                if (checkBox1.Checked == true)
                {
                    add.Enabled = false;
                }

                else if (checkBox1.Checked == false)
                {
                    add.Enabled = false;
                }
                else if (phoneBox.Text.Trim().Length != 10)
                {
                    phoneBox.Focus();
                }
                else if (phoneBox.Text.Trim().Length == 10)
                {
                    if (validate_emailaddress.IsMatch(emailBox.Text) == true)
                    {
                        add.Enabled = true;
                    }
                }
                else
                {
                    add.Enabled = true;
                }
            }
        }

        private void BackPictureBox1_Click(object sender, EventArgs e)
        {
            CvManagement cvManagement = new CvManagement(admin);
            cvManagement.Show();
            this.Hide();
        }
    }
}