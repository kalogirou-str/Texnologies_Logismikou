﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cvManagement
{
    public partial class UserAddAdmin : Form
    {

        string connectionString;
        Admin admin;

        public UserAddAdmin(Admin admin)
        {
            InitializeComponent();

            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);

            this.admin = admin;

            connectionString = @"Data Source=C:\Users\strat\Desktop\TexnologiesLogismikou-main\cvManagement\bin\Debug\students.db; Version = 3";
        }

        private void add_Click(object sender, EventArgs e)
        {
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                con.Open();
                try
                {
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.CommandText = "insert into students_reg (FIRST_NAME,LAST_NAME,USERNAME,PASSWORD)values('" + firstName.Text + "', '" + lastName.Text + "', '" + user.Text + "', '" + pass.Text + "')";
                    cmd.Connection = con;
                    int i = cmd.ExecuteNonQuery();

                    cmd = con.CreateCommand();
                    cmd.CommandText = "SELECT ID FROM students_reg WHERE USERNAME='" + user.Text + "'";  //set the passed query
                    int id = Convert.ToInt32(cmd.ExecuteScalar());
                    cmd.CommandText = "insert into students_info (Id, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest)values('" + id + "' ,'" + emailBox.Text + "', '" + maleButton.Text + "', '" + phoneBox.Text + "', '" + diplomaBox.Text + "', '" + languageBox.Text + "', '" + experienceBox.Text + "', '" + skillBox.Text + "', '" + interestBox.Text + "')";
                    i = cmd.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    con.Close();
                    CvManagement cv = new CvManagement(admin);
                    cv.Show();
                    this.Hide();
                    
                }
            }
        }

        private void UserAddAdmin_Load(object sender, EventArgs e)
        {
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);
        }
    }
}
