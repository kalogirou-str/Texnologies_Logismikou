﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cvManagement
{
    public class Human
    {
        private string username;
        private string password;

        public Human(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public string Usename   // property
        {
            get { return username; }   // get method
            set { username = value; }  // set method
        }
        public string Password   // property
        {
            get { return password; }   // get method
            set { password = value; }  // set method
        }
    }
}
