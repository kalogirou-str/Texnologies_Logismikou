﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cvManagement
{
    public partial class Biography : Form
    {
        string connectionString = @"Data Source= C:\Users\strat\Desktop\TexnologiesLogismikou-main\cvManagement\bin\Debug\students.db; Version = 3";
        Student student;
        Admin admin;
        int Id;


        bool exists;
        string User;

        //for student
        public Biography(Student student)
        {
            InitializeComponent();
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);

            this.student = student;

            //Grab student's ID
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                try
                {
                    
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.Connection = con;

                    con.Open();

                    
                    cmd.CommandText = "select ID from students_reg where USERNAME = '"+student.Usename+"'";

                    // The row ID is a 64-bit value - cast the Command result to an Int64.
                    //
                    Int64 LastRowID64 = (Int64)cmd.ExecuteScalar();

                    // Then grab the bottom 32-bits as the unique ID of the row.
                    //
                    Id = (int)LastRowID64;

                    fullBoxes(Id);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        //for admin
        public Biography(int id, Admin admin)
        {
            InitializeComponent();
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);

            this.admin = admin;
            Id = id;

            fullBoxes(id);
        }


        private void fullBoxes(int id)
        {
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                try
                {
                    SQLiteCommand cmd = new SQLiteCommand();
                    cmd.CommandText = "SELECT * FROM students_info where ID = '" + id + "'";
                    cmd.Connection = con;

                    con.Open();
                    SQLiteDataAdapter da = new SQLiteDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    int i = cmd.ExecuteNonQuery();
                    con.Close();
                    if (dt.Rows.Count > 0)
                    {
                        emailBox.ReadOnly = true;
                        phoneBox.ReadOnly = true;
                        exists = true;
                        addBiographyData.Text = "Edit your Biography";
                        //initializing the boxes from the database
                        exists = true;
                        con.Open();  //Initiate connection to the db
                        cmd.CommandText = "SELECT Email FROM students_info where ID = '" + id + "'";
                        string email = cmd.ExecuteScalar().ToString();
                        emailBox.Text = email;
                        cmd.CommandText = "SELECT Gender FROM students_info where ID = '" + id + "'";
                        string gender = cmd.ExecuteScalar().ToString();
                        if (gender == "male")
                        {
                            maleButton.Checked = true;
                        }
                        else
                        {
                            femaleButton.Checked = true;
                        }
                        cmd.CommandText = "SELECT Phone FROM students_info where ID = '" + id + "'";
                        string Phone = cmd.ExecuteScalar().ToString();
                        phoneBox.Text = Phone;
                        cmd.CommandText = "SELECT Diploma FROM students_info where ID = '" + id + "'";
                        string Diploma = cmd.ExecuteScalar().ToString();
                        diplomaBox.Text = Diploma;
                        cmd.CommandText = "SELECT Language FROM students_info where ID = '" + id + "'";
                        string Language = cmd.ExecuteScalar().ToString();
                        languageBox.Text = Language;
                        cmd.CommandText = "SELECT Experience FROM students_info where ID = '" + id + "'";
                        string Experience = cmd.ExecuteScalar().ToString();
                        experienceBox.Text = Experience;
                        cmd.CommandText = "SELECT Skill FROM students_info where ID = '" + id + "'";
                        string Skill = cmd.ExecuteScalar().ToString();
                        skillBox.Text = Skill;
                        cmd.CommandText = "SELECT Interest FROM students_info where ID = '" + id + "'";
                        string Interest = cmd.ExecuteScalar().ToString();
                        interestBox.Text = Interest;
                        con.Close();
                    }
                    else
                    {
                        exists = false;
                        femaleButton.Checked = true;
                    }

                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void addBiographyData_Click(object sender, EventArgs e)
        {
            using (SQLiteConnection con = new SQLiteConnection(connectionString))
            {
                try
                {
                    string gender="female";
                    SQLiteCommand cmd = new SQLiteCommand();
                    if (exists == false)
                    {
                        if (maleButton.Checked == true)
                        {
                            gender = "male";
                        }
                        cmd.CommandText = "insert into students_info (Id, Email, Gender, Phone, Diploma, Language, Experience, Skill, Interest)values('"+Id+"' ,'" + emailBox.Text + "', '" + gender + "', '" + phoneBox.Text + "', '" + diplomaBox.Text + "', '" + languageBox.Text + "', '" + experienceBox.Text + "', '" + skillBox.Text + "', '" + interestBox.Text + "')";
                        cmd.Connection = con;

                        con.Open();

                        int var = cmd.ExecuteNonQuery();

                        con.Close();

                    }
                    else
                    {
                        if (maleButton.Checked == true)
                        {
                            gender = "male";
                        }
                        else
                        {
                            gender = "female";
                        }
                        cmd.CommandText = "update students_info set Gender='"+gender+"', Diploma='" + diplomaBox.Text + "', Language='" + languageBox.Text + "', Experience='" + experienceBox.Text + "', Skill='" + skillBox.Text + "', Interest='" + interestBox.Text + "' where ID='" + Id + "'";
                        cmd.Connection = con;

                        con.Open();

                        int var = cmd.ExecuteNonQuery();
                        con.Close();

                    }

                    //We check who uses the app in order to send him back
                    if(student == null)
                    {
                        CvManagement cv = new CvManagement(admin);
                        cv.Show();
                    }
                    else
                    {
                        CvManagement cv = new CvManagement(student);
                        cv.Show();
                    }
                    
                    this.Hide();
                    
                  
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        
        private void Biography_Load(object sender, EventArgs e)
        {
            //full screen code
            int w = Screen.PrimaryScreen.Bounds.Width;
            int x = Screen.PrimaryScreen.Bounds.Height;
            this.Location = new Point(0, 0);
            this.Size = new Size(w, x);
        }

        private void diplomaBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void BackPictureBox1_Click(object sender, EventArgs e)
        {
            if(student != null)
            {
                CvManagement cvManagement = new CvManagement(student);
                cvManagement.Show();
                this.Hide();
            }
            else
            {
                CvManagement cvManagement = new CvManagement(admin);
                cvManagement.Show();
                this.Hide();
            }
        }
    }
}
