﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cvManagement
{
    //Implements ISpeak interface
    public class Student : Human, ISpeak
    {
        private string first_name;
        private string last_name;

        private string email;
        private string gender;
        private string phone;
        private string diploma;
        private string language;
        private string experience;
        private string skill;
        private string interest;

        //With base keyword we can refer to Human class
        public Student(string first_name, string last_name, string username, string password)
            :base(username, password)
        {
            this.first_name = first_name;
            this.last_name = last_name;
            email = "";
            gender = "";
            phone = "";
            diploma = "";
            language = "";
            experience = "";
            skill = "";
            interest = "";
        }

        public Student(string email, string gender, string phone, string diploma, string language, string experience, string skill, string interest, string username,  string password) 
            :base(username, password)
        {
            this.email = email;
            this.gender = gender;
            this.phone = phone;
            this.diploma = diploma;
            this.language = language;
            this.experience = experience;
            this.skill = skill;
            this.interest = interest;
        }

        //Getters and Setters for all variables
        public string First_name   // property
        {
            get { return first_name; }   // get method
            set { first_name = value; }  // set method
        }

        public string Last_name   // property
        {
            get { return last_name; }   // get method
            set { last_name = value; }  // set method
        }

        public string Email   // property
        {
            get { return email; }   // get method
            set { email = value; }  // set method
        }
        public string Gender   // property
        {
            get { return gender; }   // get method
            set { gender = value; }  // set method
        }
        public string Phone   // property
        {
            get { return phone; }   // get method
            set { phone = value; }  // set method
        }
        public string Diploma   // property
        {
            get { return diploma; }   // get method
            set { diploma = value; }  // set method
        }
        public string Language   // property
        {
            get { return language; }   // get method
            set { language = value; }  // set method
        }
        public string Experience   // property
        {
            get { return experience; }   // get method
            set { experience = value; }  // set method
        }
        public string Skill   // property
        {
            get { return skill; }   // get method
            set { skill = value; }  // set method
        }
        public string Interest   // property
        {
            get { return interest; }   // get method
            set { interest = value; }  // set method
        }


        public string WhoAmI()
        {
            return "Hello student!!";
        }
    }
}

